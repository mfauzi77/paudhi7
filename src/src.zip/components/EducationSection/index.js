// src/components/EducationSection/index.js
export { default } from './EducationSection';